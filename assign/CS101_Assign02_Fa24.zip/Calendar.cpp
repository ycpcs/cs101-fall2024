// CS101 Assignment 2 - Fall 2024
#include <stdio.h>

int main() {
	// TODO: Add code
	
	// MS1:
	//    1. Get user input for month and year
	//    2. Determine number of days in the month (accounting for leap years)
	//    3. Determine the day of the week for the 1st (using the Julian day calculation)
	
	
	
	
	
	
	
	// MS2:
	//    1. Validate user input
	//    2. Print month and year heading
	//    3. Print days of the week heading
	//    4. Print month calendar using a loop(s)
	
	

	return 0;
}