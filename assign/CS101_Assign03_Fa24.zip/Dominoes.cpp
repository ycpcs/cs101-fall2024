// CS101 Assignment 3 - Fall 2024
#include <stdio.h>

int main() {

	// TODO: Add code
	
	// MS1:
	//    1. Declare array for up to 20 dominoes
	//    2. Get validated user input for dominoes
	//    3. Print out initial domino state



	// MS2:
	//    1. "Tip" first domino
	//    2. Loop for 10 timesteps
	//      2a. Loop through array to determine "ready to tip" dominoes
	//      2b. Loop through array to update domino states
	//      2c. Print updated state


	
	return 0;
}