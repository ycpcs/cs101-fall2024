// TODO: add your code to this file
#include <stdio.h>
#include <math.h>

int main(void) {
	// TODO: Get user inputs
	
	// TODO: Compute hypotenuse
	
	// TODO: Print output

	return 0;
}
