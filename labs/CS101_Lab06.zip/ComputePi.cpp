// TODO: add your code to this file
#include <stdio.h>
#include <math.h>

int main(void) {
	// TODO: Get user input
	
	// TODO: Loop to compute pi
	
	// TODO: Print output

	return 0;
}
