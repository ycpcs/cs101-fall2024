// TODO: add your code to this file
#include <stdio.h>

#define MAX_NUMS 20

int main(void) {
	// TODO: Get user input for number of values and validate
	
	// TODO: Loop to obtain values and store in array
	
	// TODO: Loop to check for palindrome
	
	// TODO: Print output

	return 0;
}
